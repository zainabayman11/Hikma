package com.imagepicker.media;

/**
 * Created by rusfearuth on 16.03.17.
 */

public class VideoConfig
{
}
