package com.imagepicker;

public class FileProvider extends androidx.core.content.FileProvider {
}
